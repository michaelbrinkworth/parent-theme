<div id="listeo-listings-container">
							<div class="loader-ajax-container" style=""> <div class="loader-ajax"></div> </div>
<section id="listings-not-found" class="margin-bottom-50 col-md-12">
	<h2><?php esc_html_e('Nothing found','listeo_core'); ?></h2>
	<!--<p><?php // _e( 'We&rsquo;re sorry but we do not have any listings matching your search, try to change you search settings', 'listeo_core' ); ?></p>-->
	<p><?php  _e( 'We&rsquo;re sorry, there are Hypley partners in this area but are still being onboarded. Please contact your event details and what you need to', 'listeo_core' ); ?> <a target="_blank" href="mailto:justin@hypley.com"> justine@hypley.com</a> </p>
</section>